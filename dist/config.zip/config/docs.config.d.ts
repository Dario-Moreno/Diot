import { DocsConfig } from '@scripts/types';
export declare const docsConfig: DocsConfig;
//# sourceMappingURL=docs.config.d.ts.map